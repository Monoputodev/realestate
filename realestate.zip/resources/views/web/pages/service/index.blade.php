@extends('web.app.app')


@section('main-body')
<div class="main-body">

    @include('web.components.service')
    <!--=========== service section End =========-->
</div>
@endsection